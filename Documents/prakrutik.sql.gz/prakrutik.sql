-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2019 at 06:16 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prakrutik`
--

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `area_id` int(3) NOT NULL,
  `area_name` varchar(30) NOT NULL,
  `city_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`area_id`, `area_name`, `city_id`) VALUES
(1, 'Chandkheda', 1),
(2, 'naranpura', 1),
(3, 'Varachha Road', 2),
(4, 'MakarPura', 4),
(5, 'Hari nagar', 3),
(6, 'Lilia', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(3) NOT NULL,
  `p_id` int(3) NOT NULL,
  `u_id` int(3) NOT NULL,
  `c_qty` int(2) NOT NULL,
  `c_date` date NOT NULL,
  `amnt` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `p_id`, `u_id`, `c_qty`, `c_date`, `amnt`) VALUES
(8, 12, 5, 2, '2019-02-25', 720),
(9, 27, 5, 2, '2019-02-25', 120),
(10, 9, 5, 8, '2019-02-25', 4560),
(11, 52, 5, 3, '2019-02-25', 597),
(14, 12, 3, 2, '2019-02-25', 720),
(15, 11, 3, 2, '2019-02-25', 1300),
(16, 21, 3, 1, '2019-02-25', 295);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int(3) NOT NULL,
  `c_name` varchar(30) NOT NULL,
  `description` varchar(3000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `c_name`, `description`) VALUES
(1, 'Health Care', 'Stores Health Products'),
(4, 'Hair Care', 'Stores Hair care products'),
(5, 'Skin Care', 'Stores Skin care Products'),
(6, 'Baby Care', 'Stores Baby care Products');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `city_id` int(3) NOT NULL,
  `city_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `city_name`) VALUES
(1, 'Ahmedabad'),
(2, 'Surat'),
(3, 'rajkot'),
(4, 'baroda'),
(5, 'amreli');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `con_id` int(3) NOT NULL,
  `con_fname` varchar(40) NOT NULL,
  `con_lname` varchar(40) NOT NULL,
  `con_email` varchar(40) NOT NULL,
  `con_subject` varchar(40) NOT NULL,
  `con_message` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`con_id`, `con_fname`, `con_lname`, `con_email`, `con_subject`, `con_message`) VALUES
(1, 'kjnbf', 'ASflnadg', 'chavdagautam23@gmail.com', 'dfvdv', 'aefaecsdfeawferf'),
(2, 'hardik', 'Radadiya', 'jnnjkcffkjbd@gmail.com', 'scs', 'hijdin dj');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(3) NOT NULL,
  `u_id` int(3) NOT NULL,
  `f_discription` varchar(150) NOT NULL,
  `f_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `u_id`, `f_discription`, `f_date`) VALUES
(1, 1, 'This site is provides healthy products', '2018-12-12'),
(2, 2, 'In this site product searching are very easily', '2018-02-12'),
(3, 3, 'This site is provides different products', '2016-01-20'),
(4, 5, 'Outstanding delivery and awesome product', '2016-06-14');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `img_id` int(3) NOT NULL,
  `img_path` varchar(300) NOT NULL,
  `p_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`img_id`, `img_path`, `p_id`) VALUES
(1, 'Gas_away.jpg', 5),
(2, 'Flax_Seeds.jpg', 6),
(3, 'Daily_Diet_Tablet.jpg', 8),
(4, 'Tru_Health_Tablet.jpg', 9),
(8, 'HEART_STRONG _Tab.jpg', 10),
(9, 'Himaliyan_berry_juice.jpg', 11),
(10, 'Vita_diet_tablet.jpg', 12),
(11, 'Jeevan_shakti_ras.jpg', 13),
(12, 'protiwon(vanilla).jpg', 14),
(13, 'protiwon(choclate).jpg', 15),
(14, 'power_o_gold(choclate).jpg', 16),
(15, 'power_o_gold(vanilla).jpg', 17),
(16, 'Aloe_livkare_syrup.jpg', 18),
(17, 'Aloe_liv_kare_syrup(sugar_free).jpg', 19),
(18, 'Herbal_Uninorm_Syrup.jpg', 20),
(19, 'Aloe_Icy_Hair_Oil.jpg', 21),
(20, 'Almond_hair_oil.jpg', 22),
(21, 'Herbal_hair_oil.jpg', 23),
(22, 'Aloe_hair_cleanser.jpg', 24),
(23, 'Kesh_Win_Hair_Cleanser.jpg', 25),
(24, 'Aloe_vera_and_mint_soap.jpg', 26),
(25, 'Aloe_vera_and_lomon_grass_soap.jpg', 27),
(26, 'Aloe_vera,neem_and_herbs_soap.jpg', 28),
(27, 'Aloe_vera_and_kesar_soap.jpg', 30),
(28, 'Aloe_anti_ageing_cream.jpg', 31),
(29, 'Herbal_aloe_cream.jpg', 32),
(30, 'Aloe_sunscreen_lotion.jpg', 33),
(31, 'Aloe_haldi_chandan_facewash.jpg', 34),
(32, 'Herbal_facepack.jpg', 35),
(33, 'Herbal_facewash(foaming).jpg', 36),
(34, 'Keshwin_hair_conditioner.jpg', 37),
(35, 'Herbal_henna.jpg', 38),
(36, 'Organic_noni_hair_color_shampoo.jpg', 39),
(37, 'Aloe_vera_fibrous_juice.jpg', 40),
(38, 'berry_churan.jpg', 41),
(39, 'Herbal_face_scrub.jpg', 44),
(40, 'Aloe_baby_soap.jpg', 45),
(41, 'Aloe_baby_talcum_powder.jpg', 52),
(42, 'Aloe_baby_hair_and_body_massage_oil.jpg', 54),
(44, 'organic.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `order_item`
--

CREATE TABLE `order_item` (
  `order_item_id` int(3) NOT NULL,
  `p_id` int(3) DEFAULT NULL,
  `o_id` int(3) DEFAULT NULL,
  `c_qty` int(3) NOT NULL,
  `amnt` decimal(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_item`
--

INSERT INTO `order_item` (`order_item_id`, `p_id`, `o_id`, `c_qty`, `amnt`) VALUES
(5, 8, 9, 4, '1800.00'),
(6, 12, 10, 3, '1080.00'),
(7, 19, 11, 9, '2975.00'),
(8, 32, 11, 2, '2975.00'),
(9, 8, 11, 2, '2975.00'),
(10, 9, 12, 3, '1710.00'),
(11, 9, 13, 3, '1710.00'),
(12, 8, 14, 3, '1350.00'),
(13, 8, 15, 4, '1800.00'),
(14, 11, 16, 4, '2600.00'),
(15, 9, 17, 4, '2280.00'),
(16, 14, 18, 3, '3705.00'),
(17, 9, 18, 4, '3705.00'),
(18, 8, 19, 0, '0.00'),
(19, 8, 20, 3, '1350.00'),
(20, 8, 21, 4, '1800.00'),
(21, 8, 22, 2, '2340.00'),
(22, 10, 22, 4, '2340.00'),
(23, 8, 23, 4, '3100.00'),
(24, 11, 23, 2, '3100.00'),
(25, 8, 25, 3, '1350.00'),
(26, 8, 26, 3, '3060.00'),
(27, 9, 26, 3, '3060.00'),
(28, 8, 27, 2, '900.00'),
(29, 8, 28, 2, '900.00'),
(30, 11, 29, 4, '3950.00'),
(31, 8, 29, 3, '3950.00'),
(32, 10, 30, 2, '720.00'),
(33, 8, 31, 1, '450.00'),
(34, 40, 32, 1, '375.00'),
(35, 40, 33, 2, '750.00'),
(36, 9, 34, 2, '1140.00'),
(37, 9, 35, 2, '1140.00'),
(38, 8, 36, 3, '1350.00'),
(39, 8, 37, 3, '1350.00'),
(40, 9, 37, 2, '1140.00'),
(41, 37, 38, 1, '99.00'),
(42, 24, 38, 2, '790.00'),
(44, 55, 40, 3, '1185.00'),
(45, 9, 41, 1, '570.00'),
(46, 22, 42, 1, '325.00'),
(47, 8, 43, 1, '450.00'),
(48, 21, 44, 1, '295.00'),
(49, 9, 45, 4, '2280.00'),
(50, 8, 45, 3, '1350.00'),
(51, 12, 45, 3, '1080.00'),
(52, 9, 46, 3, '1710.00'),
(53, 8, 47, 1, '450.00');

-- --------------------------------------------------------

--
-- Table structure for table `order_master`
--

CREATE TABLE `order_master` (
  `o_id` int(3) NOT NULL,
  `u_id` int(3) NOT NULL,
  `order_date` date NOT NULL,
  `payment_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_master`
--

INSERT INTO `order_master` (`o_id`, `u_id`, `order_date`, `payment_status`) VALUES
(9, 3, '2019-02-17', 0),
(10, 3, '2019-02-17', 0),
(11, 4, '2019-02-17', 0),
(12, 4, '2019-02-18', 0),
(13, 3, '2019-02-18', 0),
(14, 3, '2019-02-18', 0),
(15, 3, '2019-02-18', 0),
(16, 3, '2019-02-19', 0),
(17, 3, '2019-02-19', 0),
(18, 7, '2019-02-19', 0),
(19, 7, '2019-02-19', 0),
(20, 7, '2019-02-19', 0),
(21, 7, '2019-02-19', 0),
(22, 7, '2019-02-19', 0),
(23, 7, '2019-02-19', 0),
(24, 7, '2019-02-19', 0),
(25, 7, '2019-02-19', 0),
(26, 7, '2019-02-19', 0),
(27, 7, '2019-02-19', 0),
(28, 7, '2019-02-19', 0),
(29, 4, '2019-02-20', 0),
(30, 4, '2019-02-20', 0),
(31, 4, '2019-02-21', 0),
(32, 2, '2019-02-21', 1),
(33, 2, '2019-02-21', 1),
(34, 2, '2019-02-21', 0),
(35, 2, '2019-02-21', 0),
(36, 2, '2019-02-21', 0),
(37, 2, '2019-02-21', 0),
(38, 2, '2019-02-21', 0),
(39, 2, '2019-02-24', 0),
(40, 5, '2019-02-25', 0),
(41, 3, '2019-02-25', 0),
(42, 5, '2019-02-25', 0),
(43, 5, '2019-02-25', 1),
(44, 5, '2019-02-25', 0),
(45, 2, '2019-02-25', 0),
(46, 2, '2019-02-25', 0),
(47, 9, '2019-02-25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `order_status_id` int(1) NOT NULL,
  `order_status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`order_status_id`, `order_status`) VALUES
(1, 'Pending'),
(2, 'Accepted'),
(3, 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `p_id` int(3) NOT NULL,
  `sub_category_id` int(3) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_description` varchar(500) NOT NULL,
  `p_price` decimal(8,2) NOT NULL,
  `p_qty` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `sub_category_id`, `p_name`, `p_description`, `p_price`, `p_qty`) VALUES
(5, 7, 'Gas Away', 'Gas not only leads to burning stomach but also is a major mood buster. It will hamper your work as you will not be able to focus.', '170.00', 0),
(6, 7, 'Flax seeds', 'Flaxseed Powder is a rich source of Omega-3 fatty acids, fiber and lignin which are having 100% naturally flaxseed powder in convenient single use sachets (vacuum sachets) to maintain freshness. \r\nThese are rich in fiber and possess lignan in flax seed which promises fighting disease. ', '130.00', 0),
(8, 3, 'Daily diet tablet', 'it enhances metabolism, controls appetite, keeps the person active all day long and fulfils the requ', '450.00', 30),
(9, 3, 'Tru Health Tablet', 'Boosts immunity, keeps the heart healthy and helpful in case of asthma. It prevents stone formation in kidneys, hemorrhoids, acidity, constipation, ulcers, headache, cold, cough, flu, infection and migraine.', '570.00', 30),
(10, 3, 'heart strong tablet', 'Strengthens heart and helps in thinning of blood which in turn improves blood circulation, prevents clot formation and blockage in the arteries.', '360.00', 30),
(11, 4, 'Himalayan Berry Juice', 'It has antioxidants and fat burning properties. It helps to regulate cholesterol level and aids in weight loss by enhancing metabolism.', '650.00', 1),
(12, 3, 'Vita diet tablet', 'Useful in physical & mental weakness. Fulfils the need of micro nutrients & vitamins. Energises the body, controls fatigue & stress.', '360.00', 30),
(13, 4, 'Jeevan sakti ras', 'Boosts energy, sharpens memory and makes body disease resistant. It strengthens heart, mind and liver and regulates blood circulation.', '450.00', 1),
(14, 5, 'Protiwon(Vanilla)', 'It fulfills the nutritive requirements of the body thereby protecting it from various diseases. It helps in building muscles and increasing haemoglobin. Daily intake of protein is a boon for children as it helps in making their body strong, healthy and increases mental ability.', '475.00', 1),
(15, 5, 'Protiwon(Chocolate)', 'It fulfills the nutritive requirements of the body thereby protecting it from various diseases. It helps in building muscles and increasing haemoglobin Daily intake of protein is a boon for children as it helps in making their body strong, healthy and increases mental ability.', '475.00', 40),
(16, 5, 'Power-O-Gold(Chocolate)', 'Extremely nutritious, strengthens all parts of the body and builds immunity. It boosts memory and concentration by reducing fatigue and mental stress. It helps in the physical development of children and very good for pregnant and lactating women.', '475.00', 50),
(17, 5, 'Power-O-Gold(Vanilla)', 'Extremely nutritious, all parts of the body and builds immunty. It boosts memory and concentration by reducing fatigue and mental stress. It helps in the physical development of children and very good for pregnant and lactating women.', '475.00', 1),
(18, 6, 'Aloe LivKare Syrup', 'Increasing appetite, improving liver dysfunction,Highly effective for jaundice, hepatitis, spleen and liver diseases.	', '120.00', 1),
(19, 6, 'Aloe LivKare Syrup(Sugar Free)', 'Increasing appetite, improving liver dysfunction, \r\n• Highly effective for jaundice, hepatitis, spleen and liver diseases.', '175.00', 1),
(20, 6, 'Herbal Uninorm  Syrup', 'Effective in dissolving kidney stones,keeps uninary tract clear by naturraly excreting toxins from the system and regulates bowel movements', '140.00', 1),
(21, 8, 'Aloe Icy Hair Oli', 'Aloe ICY Hair Oil Enriched With the properties of natural herbs Aloe Icy Hair Oil is enriched with Bhringraj, Brahmi, Aloe Vera, Amla, Neem, Gudhal pushp, Nagarmotha, Menthol & Kapoor.', '295.00', 1),
(22, 8, 'Almond Hair Oil', 'Almond Hair Oil improves blood circulation in the scalp controls dandruff, repairs the damaged hair shaft, strengthens hair from the root and prevents Hair Fall.\r\n', '325.00', 1),
(23, 8, 'Herbal Hair Oil', 'Herbal Hair Oil is a blend of carefully selected such herbs. Indications: Application of oil Prevents excessive Falling of Hair, stimulates hair growth, cures dandruff, Itching of Scalp and keeps hair long, lustrous & healthy.', '250.00', 1),
(24, 9, 'Aloe Hair Cleanser(Shampoo)', 'Herbal Aloevera Cleanser Helps To Fight Against Eavy Dandruff, Flaky Scalp Disease', '395.00', 1),
(25, 9, 'Kesh Win Hair Cleanser', 'Kesh Win arbal Hair Cleanser: Harbal Hair Cleanser, anti dandruff shampoo extra conditioner.Apply oil in the roots of the hair & scalp with fingures and massage gently Harbal Kesh Win Hair Cleanser, anti dandruff shampoo & Herbal Hair Oil. Store in cool and dry place. ', '240.00', 1),
(26, 10, 'Aloe vera and mint soap', 'A natural herbal soap designed to sooth inflammed skin conditions. It provides gentle cleaning and contains aloe vera  for gentle healing and soothing.', '85.00', 1),
(27, 10, 'Aloe vera and lemon grass soap', 'It contains anti-septic properties. Toners provide hydration to your skin, which is essential in maintaining elasticity, smoothness, moisture and a more youthful appearance. Refreshes the skin and restores the pH balance of the skin. ', '60.00', 1),
(28, 10, 'Aloe vera, neem and herbs soap', 'Neem when combined with Aloe Vera provides soft, smooth and healthy skin. ... Freia Neem with Aloevera Soap provides skin shine and natural glow and this soap makes the skin smooth and soft and quietly dirt free the skin pores.', '390.00', 1),
(30, 10, 'Aloe vera and kesar soap', ' Its skin brightening and acne prevention properties makes it perfect for use in the scorching summer heat.Description:IngredientsKesar', '390.00', 1),
(31, 11, 'Aloe anti-ageing cream', 'Herbal Aloe Cream : An Anti-Septic & Enriched with AloeVera, Rose and Sandal. Aloe Cream is an excellent Anti-ageing, Anti-Wrinkle, Anti-Oxidant, Anti-Pimple, Anti- Septic and Natural Sun Screen. ', '220.00', 1),
(32, 11, 'Herbal aloe cream', 'Aloe cream is an excellent, anti-ageing, anti- wrinkle, anti-oxidant, anti-pimple, anti-septic & natural sun screen. Makes the skin young, fair, ...', '250.00', 1),
(33, 11, 'Aloe sun-screen lotion', 'Apply liberally and evenly on face and exposed parts of the body (neck, arms etc)', '425.00', 1),
(34, 12, 'Aloe haldi chandan face wash', 'Lightens skin tone and dark circles. Gently unclogs the pores and removes balckheads giving a glowing face with soft skin.\r\n\r\n', '70.00', 1),
(35, 12, 'Herbal Face Pack', 'Restores the lost shine and glow of skin. Makes the skin fair, soft and smooth.\r\nPrevents pimples, patches, fine lines, and red spots\r\nRemoves dead and dull skin. Protects the skin from infections. Regular use improves skin texture and complexion.', '50.00', 1),
(36, 12, 'Herbal face wash(foaming)', 'laksndcm ', '125.00', 1),
(37, 14, 'Keshwin hair conditioner', 'It helps to keep your hair more manageable, adds natural moisture, gives a natural shine and helps you with frizzy or dry hair. Benefits: Moisturizes the scalp & dry hair. Repairs damaged hair. Nourishes the hair with essential nutrients. Strengthens the hair. Reduces hair fall & promotes hair growth. Directions to use : After shampoo take adequate quantity of Kesh Win Hair Conditioner massage through the length of hair and rinse thoroughly after 2 minutes of application.', '99.00', 1),
(38, 15, 'Herbal Henna', '\"Prevents hair problems like dandruff, hair falling and greying of hair. Strengthens the roots of the hair. Moisturizes hair and makes them silky and shiny. Promotes hair growth. Excellent for dull and lifeless hair.\"', '80.00', 1),
(39, 9, 'Organic noni hair color shampoo', 'kdfuhdksjnfvihb', '80.00', 1),
(40, 4, 'Aloe Vera Fibrous Juice', 'The laxative property of aloe vera boosts digestion. It helps to strengthen joints, immune system and controls irritable bowel syndrome. Being a natural detoxifier, it helps to lose weight by releasing excess of toxins from the body.', '375.00', 1),
(41, 7, 'Berry Churan', 'Useful to increase appetite, constipation & gastric problem.', '250.00', 1),
(44, 16, 'Herbal face scrub', 'It removes blackheads, dead skin cells and revitalises the skin texture. It increases skin elasticity and makes it firm.', '300.00', 1),
(45, 17, 'Aloe baby soap', 'Makes the baby\'s delicate skin soft and mushy. Does not hurt the eyes and keeps the skin rash free.', '100.00', 1),
(52, 18, 'Aloe baby talcum powder', 'Anti-sweat talcum powder is refreshing and rejuvenating in scorching heat. It will keep the baby odour free and itch free.', '199.00', 1),
(54, 19, 'Aloe baby hair and body massage oil', 'Develops strong bones strong muscles of the baby. Keeps the baby\'s skin moisturized and gives silky hair.', '299.00', 1),
(55, 17, 'Aloe Baby Hair And Body Wash', 'Aloe Baby Hair and  Body Wash is an herbal solution enriched with Aloe Vera that will keep the baby\'s skin soft and tender.', '395.00', 30);

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `sub_category_id` int(3) NOT NULL,
  `c_id` int(3) NOT NULL,
  `sub_category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`sub_category_id`, `c_id`, `sub_category_name`) VALUES
(3, 1, 'Tablets'),
(4, 1, 'juices'),
(5, 1, 'Protien powder'),
(6, 1, 'Syrup'),
(7, 1, 'Churan'),
(8, 4, 'hair Oil'),
(9, 4, 'Shampoo'),
(10, 5, 'Soap'),
(11, 5, 'Cream'),
(12, 5, 'Face wash'),
(14, 4, 'conditioner'),
(15, 4, 'Mehndi'),
(16, 5, 'scrub'),
(17, 6, 'baby soap'),
(18, 6, 'powder'),
(19, 6, 'baby massage oil');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(3) NOT NULL,
  `area_id` int(3) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `user_dob` date NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(8) NOT NULL,
  `otp` int(8) NOT NULL,
  `otp_used` int(8) NOT NULL,
  `contact_no` varchar(13) NOT NULL,
  `isadmin` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `area_id`, `user_name`, `address`, `gender`, `user_dob`, `email`, `password`, `otp`, `otp_used`, `contact_no`, `isadmin`) VALUES
(1, 1, 'Nirav', 'A-404, Shree Saran, New Chandkheda, Ahmedabad.', 'Male', '1999-01-14', 'dhwanimodi617@gmail.com', 'nirav@12', 924242, 0, '9724939071', 1),
(2, 1, 'manan', 'A/4,dharti complex,tragad road,chandkheda.', 'female', '2019-02-07', 'manan.dsharma3075@gmail.com', 'manan@12', 107645, 1, '9974785899', 0),
(3, 5, 'Saurav Mistri', '473/2907, sudarshannagar,GHB, Harinagar,amreli.', 'male', '1998-08-20', 'sauravmistri21@gmail.com', 'saurav12', 453786, 0, '9173321239', 0),
(4, 6, 'Badal Prajapati', '112-laxminagar,lilia,amreli.', 'male', '1998-12-18', 'badalprajapati124@gmail.com', 'badal@12', 0, 0, '8487837375', 0),
(5, 3, 'Gautam chavda', '114-parmeshwer flat,varachha road,surat', 'male', '1997-02-14', 'chavdagautam123@gmail.com', 'gautam@1', 0, 0, '9998489924', 0),
(7, 1, 'aswini', 'vastral', 'female', '2019-02-07', 'ashwini12@gmail.com', '123410', 0, 0, '9874563210', 0),
(9, 1, 'sadhna', 'vastral', 'female', '2019-02-17', 'sadhna@gmail.com', 'sadhna', 0, 0, '8128768147', 0),
(10, 1, 'Sad Mansuri', '256, Satyam Society, Ghatlodiya, Ahmdabad', 'male', '1998-05-06', 'sadmansuri32@gmail.com', 'sad@12', 0, 0, '1597532147', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`area_id`),
  ADD KEY `city_id` (`city_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `u_id` (`u_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`con_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`img_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `order_item`
--
ALTER TABLE `order_item`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `p_id` (`p_id`),
  ADD KEY `o_id` (`o_id`);

--
-- Indexes for table `order_master`
--
ALTER TABLE `order_master`
  ADD PRIMARY KEY (`o_id`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`order_status_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `sub_category_id` (`sub_category_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`sub_category_id`),
  ADD KEY `sub_category_ibfk_1` (`c_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`),
  ADD KEY `area_id` (`area_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
  MODIFY `area_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `city_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `con_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `img_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `order_item`
--
ALTER TABLE `order_item`
  MODIFY `order_item_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `order_master`
--
ALTER TABLE `order_master`
  MODIFY `o_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `order_status_id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `p_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `sub_category_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `area`
--
ALTER TABLE `area`
  ADD CONSTRAINT `area_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `user` (`u_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `user` (`u_id`);

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`);

--
-- Constraints for table `order_item`
--
ALTER TABLE `order_item`
  ADD CONSTRAINT `order_item_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`),
  ADD CONSTRAINT `order_item_ibfk_2` FOREIGN KEY (`o_id`) REFERENCES `order_master` (`o_id`);

--
-- Constraints for table `order_master`
--
ALTER TABLE `order_master`
  ADD CONSTRAINT `order_master_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `user` (`u_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`sub_category_id`) REFERENCES `sub_category` (`sub_category_id`);

--
-- Constraints for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD CONSTRAINT `sub_category_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `category` (`c_id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `area` (`area_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
